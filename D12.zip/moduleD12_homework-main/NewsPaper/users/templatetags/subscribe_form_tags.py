# from django import template
# from users.forms import SubscriberForm

# register = template.Library()

# @register.inclusion_tag('users/subscribe_form.html')
# def subscribe_form():
#     return {'subscribe_form': SubscriberForm()}